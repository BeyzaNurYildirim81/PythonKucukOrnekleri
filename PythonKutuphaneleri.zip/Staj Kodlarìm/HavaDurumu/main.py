from tkinter import *
from PIL import ImageTk,Image
import requests

url="https://api.openweathermap.org/data/3.0/onecall"
api_key="3490b832c33cecab199ad54069abab7a"
iconUrl= "http://openweathermap.org/img/wn/{}@2x.png"


def getWeather(city):
    params={"q":city, "appid":api_key, "lang":"tr"}
    data=requests.get(url,params=params).json()
    print(data)

getWeather("istanbul") #8:34 devam   https://www.youtube.com/watch?v=9Xn2Y0OTOK8

app= Tk()
app.geometry("300x450")
app.title("KK Hva Durumu")

cityEntry= Entry(app,justify="center")
cityEntry.pack(fill=BOTH,ipady=10,padx=18,pady=5)
cityEntry.focus()

searchButton=Button(app,text="Arama",font=("Arial",15))
searchButton.pack(fill=BOTH,ipady=10,padx=20)

iconLabel=Label(app)
iconLabel.pack()

locationLabel=Label(app,font=("Arial",40))
locationLabel.pack()

tempLabel= Label(app,font=("Arial",50,"bold"))
tempLabel.pack()

conditionLabel=Label(app,font=("Arial",20))
conditionLabel.pack()
app.mainloop()