
# #İngilizce metin okuyor.Türkçede sıkıntı çıkarıyor.
# import pyttsx3
# import PyPDF2
# hikaye=open("An Introduction to Statistical Learning.pdf","rb")
# pdfOkuyucu= PyPDF2.PdfFileReader(hikaye)

# engine=pyttsx3.init()
# voices=engine.getProperty("voices")

# engine.setProperty("voice",voices[0].id)

# for sayfa_numarasi in range(0,pdfOkuyucu.numPages):
#     sayfa=pdfOkuyucu.getPage(sayfa_numarasi)
#     yazi=sayfa.extract_text()
#     engine.say(yazi)
#     engine.runAndWait()





# #Okuduğu metni mp3 olarak kaydediyor.
from gtts import gTTS
import os
from os import path

dosyaadi="metin"
def dosyaVarmi(dosya):
    return path.exists(dosya)

dosya= open(f"{dosyaadi}.txt",encoding="utf-8")
yazi=dosya.read()
print(yazi)
cikti=gTTS(text=yazi,lang="tr", slow=False)
if dosyaVarmi(f"{dosyaadi}.mp3"):
    print("seslendiriliyor.")
    os.system(f"{dosyaadi}.mp3")
else:
    print("dosyanız oluşturuluyor")
    cikti.save(f"{dosyaadi}.mp3")
    print("seslendiriliyor")
    os.system(f"{dosyaadi}.mp3")
dosya.close()
