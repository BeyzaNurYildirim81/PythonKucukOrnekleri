
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from email.mime.text import MIMEText

def sendMail(toMail, subject, content):

    #fromMail kimden gideceği :)
    fromMail="mailgonderici81@gmail.com"
    server= smtplib.SMTP("smtp.gmail.com",587)

    server.starttls()
    #alruxlvlblcrxosb
    server.login(fromMail,"182804003")

    message= MIMEMultipart('alternative')
    message["Subject"]=subject

    htmlContent=MIMEText(content,"html")
    message.attach(htmlContent)

    server.sendmail(
        fromMail,
        toMail,
        message.as_string()
    )
    server.quit()